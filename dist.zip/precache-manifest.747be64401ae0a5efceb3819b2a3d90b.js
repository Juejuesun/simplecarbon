self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "18c5bc0c8594229472c4",
    "url": "css/app.b45e16a4.css"
  },
  {
    "revision": "73164bb54541378d4c45",
    "url": "css/chunk-vendors.9c9e005d.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "223968006f3db9e82b92e2918546fc47",
    "url": "index.html"
  },
  {
    "revision": "18c5bc0c8594229472c4",
    "url": "js/app.b7196dfe.js"
  },
  {
    "revision": "73164bb54541378d4c45",
    "url": "js/chunk-vendors.72965e2a.js"
  },
  {
    "revision": "bb925267fa0d6239d9359df7719410ac",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  }
]);